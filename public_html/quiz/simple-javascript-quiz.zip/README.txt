A Pen created at CodePen.io. You can find this one at https://codepen.io/kklumpp13/pen/xVwBKE.

 Based on the "Simple JavaScript Quiz" tutorial by Eduonix. Vanilla JavaScript version. 